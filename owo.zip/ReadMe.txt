1. install the resource pack as normal
2. open minecraft 1.16.1
3. go to "options"
4. activate the resource pack as normal
5. go to "language"
6. select "Engwish"
7. suffer for eternity ;)